# ModNest Launcher

Minecraft-Launcher mit Zugriff auf **Modrinth** und **CurseForge**, frei sortierbarer Mod-Liste und eigenen Kategorien.

## Starten

Voraussetzung: Windows und [Python 3.10+](https://www.python.org/downloads/).

1. **Erster Start:** Doppelklick auf `start.bat`. Die Datei legt die Python-Umgebung an und installiert die Abhängigkeiten, was einmalig etwa eine Minute dauert. Außerdem erstellt sie die Verknüpfung **ModNest** auf dem Desktop und in diesem Ordner.
2. **Danach:** einfach die Verknüpfung **ModNest** benutzen. Es öffnet sich kein Konsolenfenster, sondern ein Startbildschirm mit Ladebalken.

Falls etwas kaputt ist, starte einfach wieder `start.bat`. Die Datei repariert die Umgebung bei Bedarf.

## Funktionen

- **Instanzen**: beliebig viele Modpacks mit eigener Minecraft-Version und eigenem Loader (Vanilla, Fabric, Quilt, Forge, NeoForge). Rechtsklick zum Umbenennen oder Löschen.
- **Mods, Texturepacks & Shader**: jeweils ein eigener Tab mit denselben Funktionen:
  - Einträge per **Drag & Drop** in jede Reihenfolge und Kategorie ziehen. Auch ganze Kategorien lassen sich verschieben, alternativ mit den Buttons ↑/↓.
  - **Kategorien** anlegen, umbenennen (Doppelklick), einfärben und löschen. Neue Einträge werden automatisch einsortiert.
  - Per Checkbox aktivieren oder deaktivieren. Dabei wird die Datei zu `.disabled` umbenannt.
  - **⚙ Version ändern**: per Klick auf das Zahnrad eine andere, z.B. ältere Version wählen. Bewusst gewählte Versionen sind mit 📌 markiert.
  - **Texturepacks**: Die Reihenfolge wird beim Start in Minecraft übernommen (oben = höchste Priorität).
  - **Shader** brauchen Iris oder OptiFine. Im Shader-Tab gibt es dafür einen Button „Iris installieren“.
- **Entdecken**: Mods, Texturepacks und Shader auf Modrinth oder CurseForge suchen. „Neueste installieren“ ist der Standard. Optional kannst du mit „⚙ Version wählen …“ eine bestimmte Version installieren. Pflicht-Abhängigkeiten von Mods werden mitinstalliert.
- **Spielen**: lädt Minecraft, den Loader und die passende Java-Version automatisch herunter.

Die Anordnung und die Kategorien werden in `instance.json` im Instanz-Ordner gespeichert. Alle Daten liegen unter `%APPDATA%\ModNest`.

## CurseForge

CurseForge verlangt einen eigenen API-Key. Den bekommst du kostenlos auf https://console.curseforge.com. Trag ihn dann unter ⚙ Einstellungen ein.
Manche Autoren verbieten Downloads über Drittanbieter-Launcher. Solche Mods musst du von der Webseite laden und in den `mods`-Ordner legen.

## Konten (Microsoft & Offline)

Unten links neben „Spielen“ sitzt der Konto-Button. Darüber kannst du mehrere Konten hinzufügen, zwischen ihnen wechseln und dich abmelden.

- **Offline-Konto**: nur ein Spielername. Damit funktionieren Singleplayer und LAN- oder Offline-Server.
- **Microsoft-Konto**: echtes Minecraft-Konto mit Skin, Online-Servern und Realms. Die Anmeldung läuft über einen Gerätecode: Der Launcher zeigt einen Code an, du gibst ihn auf microsoft.com/link ein und meldest dich dort an. Dein Passwort sieht der Launcher nie.
  Der Launcher speichert nur den Refresh-Token, mit Windows-DPAPI verschlüsselt in `%APPDATA%\ModNest\accounts.json`. Bei jedem Start wird der Token automatisch erneuert.

### Microsoft-Login einrichten (einmalig)

Microsoft verlangt, dass jeder Launcher eine eigene Azure-App hat:

1. Öffne https://portal.azure.com, gehe zu **Microsoft Entra ID → App-Registrierungen → Neue Registrierung**.
   - Name: z.B. `ModNest Launcher`
   - Kontotypen: **„Nur persönliche Microsoft-Konten“**
   - Umleitungs-URI: leer lassen
2. In der App unter **Authentifizierung**: **„Öffentliche Clientflows zulassen“ → Ja** und speichern.
3. Kopiere die **Anwendungs-ID (Client-ID)** von der Übersichtsseite und trag sie unter ⚙ Einstellungen → „Microsoft Client-ID“ ein.
4. **Freischaltung für Minecraft beantragen**: Neue Apps dürfen die Minecraft-API erst nach einer Prüfung durch Microsoft nutzen. Das Formular findest du unter https://aka.ms/mce-reviewappid. Bis zur Freischaltung, die einige Tage dauern kann, meldet der Launcher „Minecraft hat die Anmeldung abgelehnt (403)“.

## Bekannte Einschränkungen

- Die Reihenfolge in der Liste dient deiner Übersicht. Minecraft-Loader laden Mods unabhängig vom Dateinamen bzw. von der Reihenfolge.
